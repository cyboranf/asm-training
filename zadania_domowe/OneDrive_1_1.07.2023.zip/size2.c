#include <stdio.h>

int main() {
    printf("size2.c\n\n");
    
    printf("sizeof(unsigned char) = %d\n", sizeof(unsigned char));
    printf("sizeof(unsigned short) = %d\n", sizeof(unsigned short));
    printf("unsigned sizeof(int) = %d\n", sizeof(unsigned int));
    printf("sizeof(unsigned long) = %d\n", sizeof(unsigned long));
    printf("sizeof(unsigned long int) = %d\n", sizeof(unsigned long int));
    printf("sizeof(unsigned long long) = %d\n", sizeof(unsigned long long));
    
    return 0;
}
